create view RPT_COURSE as
  select s.stud_name, s.course, c.duration from student s JOIN courses c ON (s.course = c.course)
/

