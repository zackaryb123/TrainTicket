create view S1 as
  select "REG_NO","STUD_NAME","COURSE","FEES","CONTACT_NO","DOJ" from student where fees < 500
/

