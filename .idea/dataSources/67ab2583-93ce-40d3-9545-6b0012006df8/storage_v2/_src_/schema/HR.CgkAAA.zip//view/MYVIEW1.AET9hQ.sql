create view MYVIEW1 as
  select first_name, last_name, salary from employees where salary > 4000
/

